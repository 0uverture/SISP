The program is found in the folder "Code".
It is built using the "build.bat" file.
It is run with the "run.bat" file. 

The entirety of our solution is found in the "QueensLogic.java" file. 
Report.pdf contains the report.